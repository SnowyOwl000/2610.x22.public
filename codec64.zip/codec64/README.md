# Codec64

64-bit codec used in 2610 RSA project

## Modification History
- 30 july 2021
  - Revised codec to keep fstream internally
  - simplifies usage
