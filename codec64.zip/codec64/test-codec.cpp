//
// Created by bob on 7/30/21.
//

#include <iostream>
#include "codec64.h"

using namespace std;

#define OPF(flag) ((flag)?"pass":"fail")

int main() {
    Codec64
        codec;
    bool
        okay;
    uint8_t
        allEncoded[48],
        test1[48];
    uint32_t
        buf;
    uint16_t
        buf16;
    uint64_t
        buf64;

    // setup: generate list of bytes that generates all possible encoded output chars
    for (uint32_t i=0;i<16;i++) {
        buf = ((4 * i) << 18) + ((4 * i + 1) << 12) + ((4 * i + 2) << 6) + 4 * i + 3;
        allEncoded[3*i] = (buf >> 16) & 0xff;
        allEncoded[3*i+1] = (buf >> 8) & 0xff;
        allEncoded[3*i+2] = buf & 0xff;
    }

    // test 1: output the allEncoded list and retrieve it
    okay = true;

    codec.beginEncode("test.txt");
    for (uint8_t ch : allEncoded)
        codec.put8(ch);
    codec.endEncode();

    codec.beginDecode("test.txt");
    for (uint8_t &ch : test1)
        codec.get8(ch);
    if (codec.get8(allEncoded[0]))
        okay = false;
    codec.endDecode();

    for (uint32_t i=0;i<48;i++)
        if (allEncoded[i] != test1[i])
            okay = false;

    cout << "Test all encoded chars: " << OPF(okay) << endl;

    // test 2: encode all 8-bit chars
    okay = true;
    codec.beginEncode("test.txt");
    for (uint32_t i=0;i<256;i++)
        codec.put8((uint8_t)i);
    codec.endEncode();

    codec.beginDecode("test.txt");
    for (uint32_t i=0;i<256;i++) {
        codec.get8(test1[0]);
        if (i != test1[0])
            okay = false;
    }
    codec.endDecode();

    cout << "Encode all 8-bit values: " << OPF(okay) << endl;

    // test 3: encode all 16-bit chars
    okay = true;
    codec.beginEncode("test.txt");
    for (uint32_t i=0;i<32768;i++)
        codec.put16((uint16_t)i);
    codec.endEncode();

    codec.beginDecode("test.txt");
    for (uint32_t i=0;i<32768;i++) {
        codec.get16(buf16);
        if (i != buf16)
            okay = false;
    }
    codec.endDecode();

    cout << "Encode all 16-bit values: " << OPF(okay) << endl;

    // test 4: encode first 32K 32-bit chars
    okay = true;
    codec.beginEncode("test.txt");
    for (uint32_t i=0;i<32768;i++)
        codec.put32((uint32_t)(i<<8));
    codec.endEncode();

    codec.beginDecode("test.txt");
    for (uint32_t i=0;i<32768;i++) {
        codec.get32(buf);
        if (i != (buf >> 8))
            okay = false;
    }
    codec.endDecode();

    cout << "Encode first 32K 32-bit values: " << OPF(okay) << endl;

    // test 5: encode first 32K 64-bit chars
    okay = true;
    codec.beginEncode("test.txt");
    for (uint64_t i=0;i<32768;i++)
        codec.put64((uint64_t)(i<<24));
    codec.endEncode();

    codec.beginDecode("test.txt");
    for (uint64_t i=0;i<32768;i++) {
        codec.get64(buf64);
        if (i != (buf64 >> 24))
            okay = false;
    }
    codec.endDecode();

    cout << "Encode first 32K 64-bit values: " << OPF(okay) << endl;

    return 0;
}